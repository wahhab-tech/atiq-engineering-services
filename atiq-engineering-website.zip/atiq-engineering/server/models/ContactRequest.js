const mongoose = require('mongoose');

const ALLOWED_SERVICES = [
  'Generator Installation',
  'Generator Repair & Maintenance',
  'Generator Control Panel Services',
  'Generator Troubleshooting',
  'Generator Wiring & Electrical Services',
  'Solar Panel Installation',
  'Solar System Maintenance',
  'Solar Inverter Installation',
  'Electrical Installation',
  'Preventive Maintenance',
  'Other'
];

const contactRequestSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 120 },
    phone: { type: String, required: true, trim: true, maxlength: 30 },
    email: { type: String, required: true, trim: true, lowercase: true, maxlength: 160 },
    service: { type: String, required: true, enum: ALLOWED_SERVICES },
    message: { type: String, required: true, trim: true, maxlength: 2000 },
    status: { type: String, enum: ['new', 'contacted', 'closed'], default: 'new' },
    source: { type: String, default: 'website' }
  },
  { timestamps: true }
);

contactRequestSchema.index({ createdAt: -1 });

module.exports = mongoose.model('ContactRequest', contactRequestSchema);
module.exports.ALLOWED_SERVICES = ALLOWED_SERVICES;

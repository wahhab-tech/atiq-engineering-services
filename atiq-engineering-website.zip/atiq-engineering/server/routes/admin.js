const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const ContactRequest = require('../models/ContactRequest');
const requireAdminAuth = require('../middleware/auth');

const router = express.Router();

// Slow down brute-force login attempts: max 10 tries per 15 minutes per IP.
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: 'Too many login attempts. Please try again later.' }
});

// POST /api/admin/login
router.post('/admin/login', loginLimiter, async (req, res) => {
  try {
    const { username, password } = req.body || {};

    if (!username || !password) {
      return res.status(400).json({ success: false, message: 'Username and password are required.' });
    }

    const validUsername = process.env.ADMIN_USERNAME;
    const validPasswordHash = process.env.ADMIN_PASSWORD_HASH;

    if (!validUsername || !validPasswordHash) {
      console.error('[admin] ADMIN_USERNAME / ADMIN_PASSWORD_HASH not configured in .env');
      return res.status(500).json({ success: false, message: 'Admin login is not configured on the server.' });
    }

    if (username !== validUsername) {
      return res.status(401).json({ success: false, message: 'Invalid username or password.' });
    }

    const matches = await bcrypt.compare(password, validPasswordHash);
    if (!matches) {
      return res.status(401).json({ success: false, message: 'Invalid username or password.' });
    }

    const token = jwt.sign({ role: 'admin', username }, process.env.JWT_SECRET, { expiresIn: '12h' });

    return res.json({ success: true, token });
  } catch (err) {
    console.error('[admin] login error:', err.message);
    return res.status(500).json({ success: false, message: 'Server error. Please try again later.' });
  }
});

// GET /api/requests  (protected)
router.get('/requests', requireAdminAuth, async (req, res) => {
  try {
    const requests = await ContactRequest.find().sort({ createdAt: -1 }).lean();
    return res.json({ success: true, requests });
  } catch (err) {
    console.error('[admin] fetch requests error:', err.message);
    return res.status(500).json({ success: false, message: 'Could not load requests.' });
  }
});

// DELETE /api/requests/:id  (protected)
router.delete('/requests/:id', requireAdminAuth, async (req, res) => {
  try {
    const deleted = await ContactRequest.findByIdAndDelete(req.params.id);
    if (!deleted) {
      return res.status(404).json({ success: false, message: 'Request not found.' });
    }
    return res.json({ success: true, message: 'Request deleted.' });
  } catch (err) {
    console.error('[admin] delete request error:', err.message);
    return res.status(400).json({ success: false, message: 'Invalid request id.' });
  }
});

module.exports = router;

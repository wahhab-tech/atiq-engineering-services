const express = require('express');
const rateLimit = require('express-rate-limit');
const ContactRequest = require('../models/ContactRequest');

const router = express.Router();

// Basic abuse protection: max 8 submissions per 15 minutes per IP.
const contactLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 8,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: 'Too many requests from this device. Please try again later.' }
});

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_RE = /^(\+?92|0)?3\d{9}$/;

function validatePayload(body) {
  const errors = {};
  const name = (body.name || '').toString().trim();
  const phone = (body.phone || '').toString().trim();
  const email = (body.email || '').toString().trim();
  const service = (body.service || '').toString().trim();
  const message = (body.message || '').toString().trim();

  if (!name || name.length < 2) errors.name = 'Name must be at least 2 characters.';
  if (!PHONE_RE.test(phone.replace(/[\s-]/g, ''))) errors.phone = 'Enter a valid phone number.';
  if (!EMAIL_RE.test(email)) errors.email = 'Enter a valid email address.';
  if (!service) errors.service = 'Please select a service.';
  if (!message || message.length < 10) errors.message = 'Message must be at least 10 characters.';

  return { errors, clean: { name, phone, email, service, message } };
}

// POST /api/contact
router.post('/contact', contactLimiter, async (req, res) => {
  try {
    const { errors, clean } = validatePayload(req.body || {});

    if (Object.keys(errors).length > 0) {
      return res.status(400).json({ success: false, message: 'Please correct the highlighted fields.', errors });
    }

    const doc = await ContactRequest.create(clean);

    return res.status(201).json({
      success: true,
      message: 'Your request has been received. We will contact you shortly.',
      requestId: doc._id
    });
  } catch (err) {
    console.error('[contact] submission error:', err.message);
    if (err.name === 'ValidationError') {
      return res.status(400).json({ success: false, message: 'Invalid service selection or field values.' });
    }
    return res.status(500).json({ success: false, message: 'Server error. Please try again later.' });
  }
});

module.exports = router;

require('dotenv').config();

const path = require('path');
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const connectDB = require('./db');
const contactRoutes = require('./routes/contact');
const adminRoutes = require('./routes/admin');

const app = express();
const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, '..', 'public');

// ---- Security & parsing middleware ----
app.use(
  helmet({
    contentSecurityPolicy: false // disabled to allow Google Fonts + inline SVG data URIs used by the front end
  })
);
app.use(
  cors({
    origin: process.env.CORS_ORIGIN || true,
    methods: ['GET', 'POST', 'DELETE']
  })
);
app.use(express.json({ limit: '100kb' }));
app.use(express.urlencoded({ extended: true, limit: '100kb' }));

// ---- Static frontend ----
app.use(express.static(PUBLIC_DIR));

// ---- API routes ----
app.use('/api', contactRoutes);
app.use('/api', adminRoutes);

// ---- Health check ----
app.get('/api/health', (req, res) => {
  res.json({ success: true, status: 'ok', time: new Date().toISOString() });
});

// ---- 404 for unmatched API routes ----
app.use('/api', (req, res) => {
  res.status(404).json({ success: false, message: 'API endpoint not found.' });
});

// ---- Fallback: serve index.html for any other unmatched route ----
app.use((req, res) => {
  res.status(404).sendFile(path.join(PUBLIC_DIR, 'index.html'));
});

// ---- Central error handler ----
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error('[server] Unhandled error:', err);
  res.status(500).json({ success: false, message: 'Unexpected server error.' });
});

async function start() {
  await connectDB();
  app.listen(PORT, () => {
    console.log(`[server] Atiq Engineering website running on http://localhost:${PORT}`);
  });
}

start();

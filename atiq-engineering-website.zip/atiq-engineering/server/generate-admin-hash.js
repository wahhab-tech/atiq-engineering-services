/**
 * One-off helper: generate a bcrypt hash for your chosen admin password.
 *
 * Usage:
 *   node server/generate-admin-hash.js "YourStrongPassword123"
 *
 * Copy the printed hash into your .env file as ADMIN_PASSWORD_HASH.
 */

const bcrypt = require('bcryptjs');

const password = process.argv[2];

if (!password) {
  console.error('Usage: node server/generate-admin-hash.js "YourStrongPassword123"');
  process.exit(1);
}

const hash = bcrypt.hashSync(password, 10);
console.log('\nAdd this line to your .env file:\n');
console.log(`ADMIN_PASSWORD_HASH=${hash}\n`);

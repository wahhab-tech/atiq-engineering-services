/* ==========================================================================
   Contact / quote request form
   Client-side validation + submission to POST /api/contact
   ========================================================================== */

(function () {
  'use strict';

  var form = document.getElementById('contactForm');
  if (!form) return;

  var submitBtn = document.getElementById('submitBtn');
  var successAlert = document.getElementById('formSuccess');
  var errorAlert = document.getElementById('formError');
  var errorText = document.getElementById('formErrorText');

  var fields = {
    name: form.querySelector('#name'),
    phone: form.querySelector('#phone'),
    email: form.querySelector('#email'),
    service: form.querySelector('#service'),
    message: form.querySelector('#message')
  };

  // Prefill service from ?service=... query param (set by "Request This Service" links)
  var params = new URLSearchParams(window.location.search);
  var prefillService = params.get('service');
  if (prefillService) {
    var opt = Array.prototype.find.call(fields.service.options, function (o) {
      return o.value === prefillService;
    });
    if (opt) fields.service.value = prefillService;
  }

  function setError(fieldName, message) {
    var input = fields[fieldName];
    var errEl = form.querySelector('[data-error-for="' + fieldName + '"]');
    if (message) {
      input.classList.add('is-invalid');
      if (errEl) errEl.textContent = message;
    } else {
      input.classList.remove('is-invalid');
      if (errEl) errEl.textContent = '';
    }
  }

  function validate() {
    var valid = true;

    if (!fields.name.value.trim() || fields.name.value.trim().length < 2) {
      setError('name', 'Please enter your full name.');
      valid = false;
    } else {
      setError('name', '');
    }

    var phoneClean = fields.phone.value.replace(/[\s-]/g, '');
    if (!/^(\+?92|0)?3\d{9}$/.test(phoneClean)) {
      setError('phone', 'Enter a valid phone number, e.g. 03073001398.');
      valid = false;
    } else {
      setError('phone', '');
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fields.email.value.trim())) {
      setError('email', 'Enter a valid email address.');
      valid = false;
    } else {
      setError('email', '');
    }

    if (!fields.service.value) {
      setError('service', 'Please select a service.');
      valid = false;
    } else {
      setError('service', '');
    }

    if (!fields.message.value.trim() || fields.message.value.trim().length < 10) {
      setError('message', 'Please add a few details (at least 10 characters).');
      valid = false;
    } else {
      setError('message', '');
    }

    return valid;
  }

  Object.keys(fields).forEach(function (key) {
    fields[key].addEventListener('blur', validate);
  });

  function setLoading(isLoading) {
    submitBtn.disabled = isLoading;
    submitBtn.classList.toggle('is-loading', isLoading);
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    successAlert.classList.remove('show');
    errorAlert.classList.remove('show');

    if (!validate()) {
      var firstInvalid = form.querySelector('.is-invalid');
      if (firstInvalid) firstInvalid.focus();
      return;
    }

    var payload = {
      name: fields.name.value.trim(),
      phone: fields.phone.value.trim(),
      email: fields.email.value.trim(),
      service: fields.service.value,
      message: fields.message.value.trim()
    };

    setLoading(true);

    fetch((window.ATIQ_CONFIG ? window.ATIQ_CONFIG.apiBase : '/api') + '/contact', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    })
      .then(function (res) {
        return res.json().then(function (data) { return { ok: res.ok, data: data }; });
      })
      .then(function (result) {
        setLoading(false);
        if (result.ok && result.data.success) {
          successAlert.classList.add('show');
          form.reset();
          if (window.showToast) window.showToast('Request submitted successfully.', 'success');
          successAlert.scrollIntoView({ behavior: 'smooth', block: 'center' });
        } else {
          var msg = (result.data && result.data.message) || 'Something went wrong. Please try again.';
          errorText.textContent = msg;
          errorAlert.classList.add('show');
          if (window.showToast) window.showToast(msg, 'error');
        }
      })
      .catch(function () {
        setLoading(false);
        errorText.textContent = 'Could not reach the server. Please check your connection and try again, or call us directly at 03073001398.';
        errorAlert.classList.add('show');
        if (window.showToast) window.showToast('Network error — request not sent.', 'error');
      });
  });
})();

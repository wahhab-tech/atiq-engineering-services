/* ==========================================================================
   Admin dashboard
   Fetches GET /api/requests (protected), renders table, supports
   search filtering, delete, logout, and stats.
   ========================================================================== */

(function () {
  'use strict';

  var token = localStorage.getItem('atiq_admin_token');
  if (!token) {
    window.location.href = 'admin-login.html';
    return;
  }

  var username = localStorage.getItem('atiq_admin_username');
  var userLabel = document.getElementById('adminUserLabel');
  if (userLabel && username) userLabel.textContent = username;

  var tbody = document.getElementById('requestsBody');
  var table = document.getElementById('requestsTable');
  var emptyState = document.getElementById('emptyState');
  var searchInput = document.getElementById('searchInput');
  var refreshBtn = document.getElementById('refreshBtn');
  var logoutBtn = document.getElementById('logoutBtn');

  var statTotal = document.getElementById('statTotal');
  var statToday = document.getElementById('statToday');
  var statGenerator = document.getElementById('statGenerator');
  var statSolar = document.getElementById('statSolar');

  var allRequests = [];

  function logout() {
    localStorage.removeItem('atiq_admin_token');
    localStorage.removeItem('atiq_admin_username');
    window.location.href = 'admin-login.html';
  }

  logoutBtn.addEventListener('click', logout);

  function authFetch(url, options) {
    options = options || {};
    options.headers = Object.assign({}, options.headers, { Authorization: 'Bearer ' + token });
    return fetch(url, options).then(function (res) {
      if (res.status === 401 || res.status === 403) {
        logout();
        return Promise.reject(new Error('Unauthorized'));
      }
      return res;
    });
  }

  function escapeHtml(str) {
    var div = document.createElement('div');
    div.textContent = str == null ? '' : String(str);
    return div.innerHTML;
  }

  function formatDate(iso) {
    try {
      var d = new Date(iso);
      return d.toLocaleDateString(undefined, { day: '2-digit', month: 'short', year: 'numeric' }) +
        ' · ' + d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
    } catch (e) {
      return iso;
    }
  }

  function renderStats(list) {
    var today = new Date().toDateString();
    statTotal.textContent = list.length;
    statToday.textContent = list.filter(function (r) {
      return new Date(r.createdAt).toDateString() === today;
    }).length;
    statGenerator.textContent = list.filter(function (r) {
      return /generator/i.test(r.service || '');
    }).length;
    statSolar.textContent = list.filter(function (r) {
      return /solar/i.test(r.service || '');
    }).length;
  }

  function renderTable(list) {
    tbody.innerHTML = '';
    if (!list.length) {
      table.style.display = 'none';
      emptyState.style.display = 'block';
      return;
    }
    table.style.display = 'table';
    emptyState.style.display = 'none';

    list.forEach(function (r) {
      var tr = document.createElement('tr');
      tr.innerHTML =
        '<td class="mono" style="white-space:nowrap; font-size:12.5px;">' + escapeHtml(formatDate(r.createdAt)) + '</td>' +
        '<td><strong>' + escapeHtml(r.name) + '</strong></td>' +
        '<td><a href="tel:' + escapeHtml(r.phone) + '">' + escapeHtml(r.phone) + '</a></td>' +
        '<td><a href="mailto:' + escapeHtml(r.email) + '">' + escapeHtml(r.email) + '</a></td>' +
        '<td><span class="pill">' + escapeHtml(r.service) + '</span></td>' +
        '<td style="max-width:260px;">' + escapeHtml(r.message) + '</td>' +
        '<td><button class="icon-btn" title="Delete request" data-id="' + escapeHtml(r._id) + '"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0-1 14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2L4 6h16z"/></svg></button></td>';
      tbody.appendChild(tr);
    });

    tbody.querySelectorAll('.icon-btn').forEach(function (btn) {
      btn.addEventListener('click', function () { handleDelete(btn.getAttribute('data-id')); });
    });
  }

  function applyFilter() {
    var q = (searchInput.value || '').toLowerCase().trim();
    if (!q) {
      renderTable(allRequests);
      return;
    }
    var filtered = allRequests.filter(function (r) {
      return [r.name, r.phone, r.email, r.service, r.message].some(function (v) {
        return (v || '').toLowerCase().indexOf(q) !== -1;
      });
    });
    renderTable(filtered);
  }

  function loadRequests() {
    authFetch('/api/requests')
      .then(function (res) { return res.json(); })
      .then(function (data) {
        allRequests = (data.requests || []).sort(function (a, b) {
          return new Date(b.createdAt) - new Date(a.createdAt);
        });
        renderStats(allRequests);
        applyFilter();
      })
      .catch(function (err) {
        if (err.message !== 'Unauthorized' && window.showToast) {
          window.showToast('Could not load requests.', 'error');
        }
      });
  }

  function handleDelete(id) {
    if (!id) return;
    if (!window.confirm('Delete this request? This cannot be undone.')) return;

    authFetch('/api/requests/' + id, { method: 'DELETE' })
      .then(function (res) { return res.json().then(function (d) { return { ok: res.ok, data: d }; }); })
      .then(function (result) {
        if (result.ok) {
          allRequests = allRequests.filter(function (r) { return r._id !== id; });
          renderStats(allRequests);
          applyFilter();
          if (window.showToast) window.showToast('Request deleted.', 'success');
        } else if (window.showToast) {
          window.showToast((result.data && result.data.message) || 'Delete failed.', 'error');
        }
      })
      .catch(function (err) {
        if (err.message !== 'Unauthorized' && window.showToast) window.showToast('Delete failed.', 'error');
      });
  }

  searchInput.addEventListener('input', applyFilter);
  refreshBtn.addEventListener('click', loadRequests);

  loadRequests();
})();

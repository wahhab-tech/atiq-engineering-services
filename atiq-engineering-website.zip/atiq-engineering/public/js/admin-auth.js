/* ==========================================================================
   Admin login
   Submits to POST /api/admin/login, stores JWT in localStorage, redirects.
   ========================================================================== */

(function () {
  'use strict';

  // If already logged in, skip straight to dashboard.
  if (localStorage.getItem('atiq_admin_token')) {
    window.location.href = 'admin-dashboard.html';
    return;
  }

  var form = document.getElementById('loginForm');
  var loginBtn = document.getElementById('loginBtn');
  var errorAlert = document.getElementById('loginError');
  var errorText = document.getElementById('loginErrorText');

  function setLoading(isLoading) {
    loginBtn.disabled = isLoading;
    loginBtn.classList.toggle('is-loading', isLoading);
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    errorAlert.classList.remove('show');

    var username = form.querySelector('#username').value.trim();
    var password = form.querySelector('#password').value;

    if (!username || !password) {
      errorText.textContent = 'Please enter both username and password.';
      errorAlert.classList.add('show');
      return;
    }

    setLoading(true);

    fetch('/api/admin/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: username, password: password })
    })
      .then(function (res) {
        return res.json().then(function (data) { return { ok: res.ok, data: data }; });
      })
      .then(function (result) {
        setLoading(false);
        if (result.ok && result.data.token) {
          localStorage.setItem('atiq_admin_token', result.data.token);
          localStorage.setItem('atiq_admin_username', username);
          window.location.href = 'admin-dashboard.html';
        } else {
          errorText.textContent = (result.data && result.data.message) || 'Invalid username or password.';
          errorAlert.classList.add('show');
        }
      })
      .catch(function () {
        setLoading(false);
        errorText.textContent = 'Could not reach the server. Please try again.';
        errorAlert.classList.add('show');
      });
  });
})();

/* ==========================================================================
   Atiq Engineering & Services Corporation — shared front-end behavior
   Navbar scroll state, mobile menu, scroll reveal, WhatsApp button,
   toast notifications, footer year.
   ========================================================================== */

(function () {
  'use strict';

  // Config
  window.ATIQ_CONFIG = {
    phone: '03073001398',
    phoneIntl: '923073001398', // used for wa.me deep link
    email: 'atiqhurehman@gmail.com',
    apiBase: '/api'
  };

  // ---- Footer year ----
  document.querySelectorAll('#year').forEach(function (el) {
    el.textContent = new Date().getFullYear();
  });

  // ---- Navbar scroll state ----
  var navbar = document.getElementById('navbar');
  function onScroll() {
    if (!navbar) return;
    if (window.scrollY > 12) {
      navbar.classList.add('is-scrolled');
    } else {
      navbar.classList.remove('is-scrolled');
    }
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  // ---- Mobile menu toggle ----
  var navToggle = document.getElementById('navToggle');
  var navLinks = document.getElementById('navLinks');
  if (navToggle && navLinks) {
    navToggle.addEventListener('click', function () {
      var isOpen = navLinks.classList.toggle('is-open');
      navToggle.classList.toggle('is-open', isOpen);
      navToggle.setAttribute('aria-expanded', String(isOpen));
    });
    navLinks.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () {
        navLinks.classList.remove('is-open');
        navToggle.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  // ---- WhatsApp buttons ----
  var WHATSAPP_MESSAGE = 'Hello Atiq Engineering & Services Corporation, I would like to get information about your services.';
  function whatsappLink() {
    return 'https://wa.me/' + window.ATIQ_CONFIG.phoneIntl + '?text=' + encodeURIComponent(WHATSAPP_MESSAGE);
  }
  document.querySelectorAll('.js-whatsapp').forEach(function (el) {
    el.setAttribute('href', whatsappLink());
    el.setAttribute('target', '_blank');
    el.setAttribute('rel', 'noopener noreferrer');
  });

  // ---- Scroll reveal ----
  var revealEls = document.querySelectorAll('.reveal, .load-panel');
  if ('IntersectionObserver' in window && revealEls.length) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('in-view');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15, rootMargin: '0px 0px -40px 0px' });
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add('in-view'); });
  }

  // ---- Toast notifications ----
  window.showToast = function (message, type) {
    var stack = document.getElementById('toast-stack');
    if (!stack) return;
    var toast = document.createElement('div');
    toast.className = 'toast' + (type ? ' ' + type : '');
    toast.textContent = message;
    stack.appendChild(toast);
    setTimeout(function () {
      toast.style.opacity = '0';
      toast.style.transition = 'opacity 0.3s ease';
      setTimeout(function () { toast.remove(); }, 300);
    }, 4200);
  };
})();
